"""
Module for keeping track of the borrowed words in siSwati.
"""

BORROWED = [
    ["video", "ividiyo"],
    ["science", "isayensi"],
    ["link", "ilinki"],
    ["ameni", "ameni"],
    ["hallelujah", "haleluya"],
    ['jesus', 'jesu'],
    ["Christ", "khristu"],
    ['holiday', 'holidi'],
    ['station', 'esiteshini'],
    ['stage', 'siteji'],
    ['baba', 'babe'],
    ['nurse', 'nesi'],
    ['politics', 'politiki'],
    ['prophet', 'umbholofidi'],
    ['scheme', 'sikimu'],
    ['messiah', 'mesiya'],
    ['genes', ''],
    ['stokvel', 'sitokufela']

]
