"""
Module for keeping track of the siSwati stopwords.
"""

STOPWORDS = [
    "kutsi", "manje", "wena", "leni",
    "hawu", "hhawu",  "yewena", "kodwa"

]
