"""
Module for keeping track of the slang words for siSwati.
"""

SLANG = [
    ["mara", "kodwa"],
    ["ekse", "yebhuti"],
    ["mfe2", "mfowethu"],
    ['mfo', 'mfowethu'],
    ['ntwana', 'mntfwana'],
    ['foza', 'bafo'],
    ['uyajampisa', 'uveta infihlo'],
    ["lol", ""],
    ['kaso', 'kanjena'],
    ['kanje', 'kanjena'],
    ['shem', ''],
    ['oh', ''],
    ["nedi", "kepha"],
    ['spani', 'umsebenti']

]
